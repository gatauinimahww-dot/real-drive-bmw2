REAL DRIVE BMW — PROYEK ANDROID

Isi:
- app/src/main/assets/index.html : game HTML
- app/src/main/assets/2026_zacoe_bmw_g87_m2_widebody_carbon_fiber_kit.glb : model BMW
- MainActivity.kt : Android WebView fullscreen landscape

CARA MEMBUAT APK:
1. Ekstrak ZIP proyek ini di komputer.
2. Instal Android Studio versi terbaru.
3. Pilih Open, lalu pilih folder REAL_DRIVE_ANDROID_PROJECT.
4. Tunggu Gradle Sync selesai. Pastikan internet aktif karena Three.js dimuat dari CDN jsDelivr.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android, izinkan instalasi dari sumber tersebut bila diminta, lalu instal.

CATATAN:
- Proyek ini adalah sumber aplikasi Android yang siap dibuka di Android Studio; APK belum dikompilasi/dites di perangkat.
- Game memerlukan internet untuk mengunduh Three.js dari CDN.
- Jika model tidak tampil, cek koneksi internet dan logcat Android Studio.
